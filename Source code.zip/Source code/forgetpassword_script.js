// Retrieving the values of form elements 
const form = document.getElementById('form');
const email = document.getElementById('email');
const passwordnew = document.getElementById('passwordnew');
const password2new = document.getElementById('password2new');

form.addEventListener('submit', e => {
	e.preventDefault();
	
	checkInputs();
});

function checkInputs() {
	// trim to remove the whitespaces
	const emailValue = email.value.trim();
	const passwordnewValue = passwordnew.value.trim();
	const password2newValue = password2new.value.trim();
	
	// Validate email address
	if(emailValue === '') {
		setErrorFor(email, 'Email cannot be blank');
	} else if (!isEmail(emailValue)) {
		setErrorFor(email, 'Not a valid email');
	} else {
		setSuccessFor(email);
	}
	
	// Validate password new
	if(passwordnewValue === '') {
		setErrorFor(passwordnew, 'passwordnew cannot be blank');
	} else {
		setSuccessFor(passwordnew);
	}
	
	// Validate password 2 new
	if(password2newValue === '') {
		setErrorFor(password2new, 'password2new cannot be blank');
	} else if(passwordnewValue !== password2newValue) {
		setErrorFor(password2new, 'Passwords does not match');
	} else{
		setSuccessFor(password2new);
	}
}

// Defining a function to check error and success
function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	
	small.innerText = message;

	formControl.className = 'form-control error';
}

function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.className = 'form-control success';
}
	
// Defining a function to validate email
function isEmail(email) {
	return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);
}













